# app/utils/auth_utils.py

import jwt
from flask import request, jsonify
from functools import wraps
from ..models import User
from ..routes.auth import JWT_SECRET, JWT_ALGORITHM


def get_current_user():
    token = request.headers.get("Authorization")

    if not token:
        return None

    # תומך גם במצב שיגיע כ־"Bearer <token>"
    if token.lower().startswith("bearer "):
        token = token[7:].strip()

    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user = User.query.get(data.get("user_id"))
        return user
    except Exception:
        return None


def require_user(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user:
            return jsonify({"error": "auth required"}), 401
        return f(user, *args, **kwargs)

    return wrapper
